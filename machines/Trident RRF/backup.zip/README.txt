This ZIP is a configuration backup for a Duet 3D printer controller.

Contents:
  manifest.json       - machine identity, firmware, file list and hashes
  redactions.json      - record of sensitive values found (and, if redaction was enabled, replaced)
  object-model.json   - a snapshot of the machine's object model (network identity always redacted -
                        this is a shared privacy scrubber used by every plugin's diagnostics reports,
                        so it applies even when the rest of this backup is verbatim)
  diagnostics/         - M122 output for the mainboard and each connected CAN-FD board
  files/sys/…          - contents of 0:/sys/
  files/macros/…       - contents of 0:/macros/
  files/filaments/…    - contents of 0:/filaments/

Restore this backup from the "Backup & restore config" page in DuetWebControl.
